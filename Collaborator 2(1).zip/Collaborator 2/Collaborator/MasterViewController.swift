//
//  MasterViewController.swift
//  Collaborator
//
//  Created by Stephen Bamidele Enikanoselu on 14/5/18.
//  Copyright © 2018 Stephen Bamidele Enikanoselu. All rights reserved.
//

import UIKit
//declare the section names
var sectionHeaders = ["ONGOING", "DONE"]
//sets the section index
enum sections: Int{
    case ONGOING = 0
    case DONE = 1
}

class MasterViewController: UITableViewController, detailViewDelegate, UISplitViewControllerDelegate, PeerTopeerManagerDelegate{
    //declaring the function in the protocol PeerTopeerManagerDelegate
    func manager(_ manager: peerTopeerManager, didRecieve: Data) {
        
    }
    //Declaring the detailview delegate
    var detailViewController: DetailViewController? = nil
    //Declaring the peerTopeerManager
    var peerTopeer = peerTopeerManager()
    //Declaring the model MyTask
    var myTaskList = sectionHeader.map{_ in return [MyTask]()} // declears the taskList of a mapped array list
    //declaring Date
    let formatter = DateFormatter() //
    
    
    ///Loads the item to view
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.leftBarButtonItem = editButtonItem
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(insertNewObject(_:)))
        navigationItem.rightBarButtonItem = addButton
        if let split = splitViewController {
            let controllers = split.viewControllers
            detailViewController = (controllers[controllers.count-1] as! UINavigationController).topViewController as? DetailViewController
        }
        loadTask() // Loads the task to the tableview
        peerTopeer.delegate = self
//        peerTopeer.send(data: myTaskList[0](from: Data as! Decoder))
    }
    ///sets the task to a function loadTask
    private func loadTask(){
        let t1 = MyTask(name: "Task 1")
        myTaskList[0].append(t1)
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        let date = formatter.string(from: Date())
        myTaskList[0][0].logDetail.append("\(date)  \(myTaskList[0][0].name)")
        myTaskList[0][0].collaborators.append(peerTopeer.description)
     }
    
    override func viewWillAppear(_ animated: Bool) {
        clearsSelectionOnViewWillAppear = splitViewController!.isCollapsed
        super.viewWillAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //insert new task item
    @objc
    func insertNewObject(_ sender: Any) {
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        let date = formatter.string(from: Date())
        let indexPath = IndexPath(row: 0, section: 0)
        myTaskList[0].insert(MyTask(name: "Task \(myTaskList[0].count)"), at: 0)
        tableView.insertRows(at: [indexPath], with: .automatic)
        myTaskList[0][0].logDetail.append("\(date)  \(myTaskList[0][0].name)")
        print(myTaskList[0][0].logDetail[0])
        myTaskList[0][0].collaborators.append("<#String#>")
        print(myTaskList[0][0].collaborators[0])
        tableView.reloadData()
     }
    
    // MARK: - Segues
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            if let indexPath = tableView.indexPathForSelectedRow {
                let task = myTaskList[indexPath.section][indexPath.row]
                let controller = (segue.destination as! UINavigationController).topViewController as! DetailViewController
                controller.selectedTask = task
                controller.navigationItem.leftBarButtonItem = splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
                controller.delegate = self
            }
        }
    }
    
    // counts the number of section
    override func numberOfSections(in tableView: UITableView) -> Int {
        return sectionHeaders.count
    }
    //Gets the name in the section header
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sectionHeaders[section]
    }
    //returns the number of list in a section count
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return myTaskList[section].count
        
    }
    ///Sets the cell
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identifier: String
        guard let section = sections(rawValue: indexPath.section) else{
            fatalError("invalid section\(indexPath.section)")
        }
        switch section {
        case .ONGOING:
            identifier = "cell"
            
        case .DONE:
            identifier = "cell"
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: identifier, for: indexPath)
        let task = myTaskList[indexPath.section] [indexPath.row]
        cell.textLabel?.text = task.description
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    ///Edits a list in the table
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            myTaskList[indexPath.section].remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            
        }
    }
    ///Allows a task in the table to be moved
    override func tableView(_ tableView: UITableView, moveRowAt: IndexPath, to: IndexPath) {
        
        let movedItem = myTaskList[moveRowAt.section][moveRowAt.row]
        myTaskList[moveRowAt.section].remove(at: moveRowAt.row)
        myTaskList[to.section].insert(movedItem, at: to.row)
    }
    // declares a selected task of mytask
    var selectedTask: MyTask! = MyTask(name: "")
    //updates the table
    func update() {
        tableView.reloadData()
    }
}
//declaring an extensio to the MasterviewController to add a new functionallity
extension MasterViewController {
    //declaring a struct json Data to parse data between connected deviced in a readable format.
    var json: Data{
        get{return try! JSONEncoder().encode(myTaskList[0])}
        set{myTaskList[0] = [try! JSONDecoder().decode(MyTask.self, from: newValue)]}
    }
}

