//
//  DetailViewController.swift
//  Collaborator
//
//  Created by Stephen Bamidele Enikanoselu on 14/5/18.
//  Copyright © 2018 Stephen Bamidele Enikanoselu. All rights reserved.
//

import UIKit
// declares an array of the section headers
var sectionHeader = ["TASK", "COLLABORATORS", "LOGS"]

//declares the sectionheaders to a int
enum sectionsView: Int{
    case TASK = 0
    case COLLABORATORS = 1
    case LOGS = 2
}
//sets the protocol for the detailviewdelegate
protocol detailViewDelegate {
    var selectedTask : MyTask! {get}
    func update()
}

class DetailViewController: UITableViewController, UISplitViewControllerDelegate, TableViewCellDelegate {
    
    //Declaring the detailViewDelegate protocol
    var delegate : detailViewDelegate!
    
    //sets the task of the selected task to the view
    var selectedTask: MyTask! {
        didSet {
            tableView.reloadData()
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return sectionHeader.count
    }
    //Returns the sectionHeaders to section
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sectionHeader[section]
    }
    ///Counts and returns the number of rows in each sections
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let selectedTask = selectedTask else {return 0}
        if section == 0 {    // Task Section
            return 1
        } else if section == 1 {    // Collaborators Section
//            return (selectedTask?.collaborators.count)!
        }else if section == 2 {    // Log Section
            return selectedTask.logDetail.count
        }
        return 0
    }
    /// Sets the cells in each sections
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "detailCell", for: indexPath) as! TableViewCell
        cell.row = indexPath.row
        cell.section = indexPath.section
        cell.delegate = self
        if indexPath.section == 0 {    // Task Section
            cell.taskInput.text = selectedTask?.name
        } else if indexPath.section == 1 {  // Collaborators Section
            cell.taskInput.text = selectedTask?.collaborators[indexPath.row]
        }else if indexPath.section == 2 {   // Log Section
            cell.taskInput.text = selectedTask?.logDetail[indexPath.row]
        }
        return cell
    }
    /// updates cells in each section
    func updateCell(data: String, section: Int, row: Int) {
        if section == 0 {
            selectedTask.name = data
        } else if section == 1 {
            selectedTask.collaborators = [data]
        } else if section == 2 {
            selectedTask.logDetail = [data]
        }
        
        tableView.reloadData()
        delegate.update()
    }

}
