//
//  MyTask.swift
//  Collaborator
//
//  Created by Stephen Bamidele Enikanoselu on 14/5/18.
//  Copyright © 2018 Stephen Bamidele Enikanoselu. All rights reserved.
//

import Foundation
///sets the model to codable for readability purposes when sending and recieving data
class MyTask: Codable{
    var name: String
    var logDetail = [String]()
    var collaborators = [String]()
    
    init(name: String, logDetail: String, collaborators: String){
        self.name = name
        self.logDetail.append(logDetail)
        self.collaborators.append(collaborators)
    }
    
    init(name:String) {
        
        self.name = name
        
    }
}
extension MyTask: CustomStringConvertible {
    var description: String {
        return "\(name)"
    }
}

