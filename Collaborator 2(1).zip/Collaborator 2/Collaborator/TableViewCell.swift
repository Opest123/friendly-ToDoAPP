//
//  TableViewCell.swift
//  Collaborator
//
//  Created by Stephen Bamidele Enikanoselu on 14/5/18.
//  Copyright © 2018 Stephen Bamidele Enikanoselu. All rights reserved.
//

import UIKit
///Declaring a Protocol TableViewCellDelegate
protocol TableViewCellDelegate {
    func updateCell(data: String, section: Int, row: Int)
}

class TableViewCell: UITableViewCell, UITextFieldDelegate {

    
    
    @IBOutlet weak var taskInput: UITextField!
    // Decalared a section
    var section = -1
    // Decalared a section
    var row = -1
    // Decalared the delegate TableViewCellDelegate
    var delegate : TableViewCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        taskInput.delegate = self
    }
    ///sets the textfield properties 
    func textFieldShouldReturn(_ taskInput: UITextField) -> Bool {
        taskInput.resignFirstResponder()
        print("This Textfield is in section \(section), row \(row)")
        delegate?.updateCell(data: taskInput.text!, section: section, row: row)
        return true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
