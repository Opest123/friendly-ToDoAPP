//
//  peerTopeerManager.swift
//  Collaborator
//
//  Created by Stephen Bamidele Enikanoselu on 22/5/18.
//  Copyright © 2018 Stephen Bamidele Enikanoselu. All rights reserved.
//

import Foundation
import MultipeerConnectivity
//Declaring a protocol PeerTopeerManagerDelegate
protocol PeerTopeerManagerDelegate: AnyObject {
    //creating a Function 
    func manager(_ manager: peerTopeerManager, didRecieve: Data)
}

class peerTopeerManager: NSObject {
    static let serviceType = "collab-share"
    
    var delegate: PeerTopeerManagerDelegate?
    
    private let peerID = MCPeerID(displayName: "Stephen")
    private let serviceAdvertiser: MCNearbyServiceAdvertiser
    private let serviceBrowser: MCNearbyServiceBrowser
    
    override init() {
        let service = peerTopeerManager.serviceType
        serviceAdvertiser = MCNearbyServiceAdvertiser(peer: peerID, discoveryInfo: [peerID.displayName : UIDevice.current.name], serviceType: service)
        serviceBrowser = MCNearbyServiceBrowser(peer: peerID, serviceType: service)
        super.init()
        serviceAdvertiser.delegate = self
        serviceAdvertiser.startAdvertisingPeer()
        serviceBrowser.delegate = self
        serviceBrowser.startBrowsingForPeers()
   }
    deinit {
        serviceAdvertiser.stopAdvertisingPeer()
        serviceBrowser.stopBrowsingForPeers()
    }
    
    lazy var session: MCSession = {
        let session = MCSession(peer: peerID, securityIdentity: nil, encryptionPreference: .required)
        session.delegate = self
        return session
    }()
    
    func invite(peer: MCPeerID, timeout t: TimeInterval = 10){
        print("\(peer.displayName)")
        serviceBrowser.invitePeer(peer, to: session, withContext: nil, timeout: t)
    }
    
    func send(data: Data){
        do{
            try session.send(data, toPeers: session.connectedPeers, with: .reliable)
        }catch{
            print("Error \(error) sending \(data.count)")
        }
    }
}
extension peerTopeerManager: MCNearbyServiceAdvertiserDelegate{
    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didReceiveInvitationFromPeer peerID: MCPeerID, withContext context: Data?, invitationHandler: @escaping (Bool, MCSession?) -> Void) {
        print("Recieve invitation from \(peerID)")
        invitationHandler(true, self.session)
    }
}
extension peerTopeerManager: MCSessionDelegate{
    public func session(_ session: MCSession, peer peerID: MCPeerID, didChange state: MCSessionState){
        print("\(state)")
    }
    public func session(_ session: MCSession, didReceive data: Data, fromPeer peerID: MCPeerID){
        print("\(data.count)")
        delegate?.manager(self, didRecieve: data)
    }
    public func session(_ session: MCSession, didReceive stream: InputStream, withName streamName: String, fromPeer peerID: MCPeerID){
        print("\(streamName)")
    }
    public func session(_ session: MCSession, didStartReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, with progress: Progress){
        print("\(resourceName)")
    }
    func session(_ session: MCSession, didFinishReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, at localURL: URL?, withError error: Error?){
        print("\(resourceName)")
    }
}
extension peerTopeerManager: MCNearbyServiceBrowserDelegate{
    func browser(_ browser: MCNearbyServiceBrowser, foundPeer peerID: MCPeerID, withDiscoveryInfo info: [String : String]?) {
        print("\(peerID.displayName)")
        invite(peer: peerID)
    }
    
    func browser(_ browser: MCNearbyServiceBrowser, lostPeer peerID: MCPeerID) {
        print("\(peerID.displayName)")
    }
}
