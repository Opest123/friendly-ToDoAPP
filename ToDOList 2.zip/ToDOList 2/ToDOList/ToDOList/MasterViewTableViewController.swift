//
//  MasterViewTableViewController.swift
//  ToDOList
//
//  Created by Stephen Bamidele Enikanoselu on 19/4/18.
//  Copyright © 2018 Stephen Bamidele Enikanoselu. All rights reserved.
//

import UIKit

class MasterViewTableViewController: UITableViewController, detailViewDelegate {

    //Declares a variable
    var selectedTask : MyList = MyList(title:" ", complete: false, date: Date(), dueDate: false)
    
    //Declares a variable for the indexed task in a cell
    var selectedTaskIndex : Int? = nil
   
    //Updates the tableView with the with an update taskList or populates the view with its
    //initial tasklist and reloads the tableView.
    func update() {
        navigationController?.popViewController(animated: true)
        if let listIndex = selectedTaskIndex {
          MyTaskList[listIndex] = selectedTask
        } else {
          MyTaskList.append(selectedTask)
        }
        tableView.reloadData()

    }
    
    //
    func cancel() {
        navigationController?.popViewController(animated: true)
    }

    //Declares MyList Array in MyTaskList Variable
    var MyTaskList = [MyList]()

    @IBOutlet weak var editButton: UIBarButtonItem!
    @IBOutlet weak var addButton: UIBarButtonItem!
    
    //Sets the editButton and loads up the testData function to the tableView
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.leftBarButtonItem = self.editButtonItem
        
        //load test data
        testData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    //Sets a predefined taskList
    private func testData() {
      let a = MyList(title: "Task 1", complete: true, date: Date(), dueDate: true)
      let b = MyList(title: "Task 2", complete: true, date: Date(), dueDate: true)
      let c = MyList(title: "Task 3", complete: true, date: Date(timeIntervalSinceNow: 20000), dueDate: true)
      MyTaskList += [a, b, c]
    }

    // Sets the number of section in the tableView
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    //Counts the number of rows in a particular section
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return MyTaskList.count
    }

    //Sets the model  in each cell of the tableView
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let task =  MyTaskList[indexPath.row]
        cell.textLabel?.text = task.title
        if task.dueDate {
            cell.detailTextLabel?.text = dateFormatter.string(from: task.date)
        } else {
          cell.detailTextLabel?.text = ""
        }
        if task.complete{
            cell.accessoryType = .checkmark
        } else {
            cell.accessoryType = .none
        }
        return cell
    }

    //shows if a task is complete it should be checked or not
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let task = MyTaskList[indexPath.row]
        task.complete = !task.complete
        tableView.reloadRows(at: [indexPath], with: .none)
    }
    
    // Edits and reloads the tableView when a row is edited
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            MyTaskList.remove(at: indexPath.row)
            tableView.reloadData()
        }
    }


    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */


    // MARK: - Navigation

    // Navigates the MasterViewtableController to the DetailViewViewController.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "showEdit"{
            let dvc = segue.destination as! DetailViewViewController
            dvc.delegate = self
            if let indexPath = self.tableView.indexPath(for: sender as! UITableViewCell) {
                selectedTaskIndex = indexPath.row
                selectedTask = MyTaskList[indexPath.row]
            }
        } else if segue.identifier == "showAdd" {
            let dvc = segue.destination as! DetailViewViewController
            dvc.delegate = self
            selectedTaskIndex = nil
            selectedTask = MyList(title:" ", complete: false, date: Date(), dueDate: false)
        }
        // Sets the tableView to be Edited
        setEditing(false, animated: true)

    }


}
