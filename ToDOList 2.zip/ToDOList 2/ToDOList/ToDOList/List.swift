//
//  List.swift
//  ToDOList
//
//  Created by Stephen Bamidele Enikanoselu on 19/4/18.
//  Copyright © 2018 Stephen Bamidele Enikanoselu. All rights reserved.
//

import Foundation
//Creates a class
class MyList{
    //Declares variables and their types
    var title: String
    var complete: Bool
    var date: Date
    var dueDate: Bool
    
    //Populates MyList with its actual dataTypes
    init(title: String, complete: Bool, date: Date, dueDate: Bool) {
        
        self.title = title
        self.complete = complete
        self.date = date
        self.dueDate = dueDate
        
    }
}
