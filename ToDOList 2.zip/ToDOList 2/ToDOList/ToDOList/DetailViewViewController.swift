//
//  DetailViewViewController.swift
//  ToDOList
//
//  Created by Stephen Bamidele Enikanoselu on 19/4/18.
//  Copyright © 2018 Stephen Bamidele Enikanoselu. All rights reserved.
//

import UIKit

//Calls the segue protocol in the MasterViewTablecontroller

protocol detailViewDelegate {
    var selectedTask : MyList {get}
    var selectedTaskIndex : Int? {get}
    func update()
    func cancel()
}

class DetailViewViewController: UIViewController, UITextFieldDelegate {

    //Declaring protocol detailViewDelegate

    var delegate : detailViewDelegate!
    
    //Declaring didSave
    
    var didSave : Bool = false
    
    //Cancels the View loaded
    
    @IBAction func cancelButton(_ sender: UIBarButtonItem) {
        delegate.cancel()
    }
    
    //saves the view and updates the MasterViewTableVuewController
    
    @IBAction func saveButton(_ sender: UIBarButtonItem) {
        didSave = true
        delegate.update()
    }
    
    //Condition placed on switch
    
    @IBAction func switchChecked(_ sender: UISwitch) {
        if sender.isOn{
            datePick.isEnabled = true
        } else {
            datePick.isEnabled = false
        }
    }
    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var checkSwitch: UISwitch!
    @IBOutlet weak var datePick: UIDatePicker!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    //dissappears the keyboard after the return button is pressed
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    //didsave loads on the MasterViewTableView after the DetailViewController disappears.
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        if didSave {
          let task = delegate.selectedTask
            task.title = textField.text!
          task.dueDate = checkSwitch.isOn
          task.date = datePick.date
        }
    }
    //Displays the actors called
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let task = delegate.selectedTask
        textField.text = task.title
        checkSwitch.isOn = task.dueDate
        datePick.date = task.date
        allowSave()
        switchChecked(checkSwitch)
    }
    
    //Disables the save button
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        saveButton.isEnabled = false
    }
    
    //Turns on the Save button
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        allowSave()
    }
    //Condition placed on the Save button
    
    func allowSave() {
        let text = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        saveButton.isEnabled = !text.isEmpty
    }

}
